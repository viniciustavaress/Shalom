# Pasta de uploads
Esta pasta armazena as imagens dos produtos do Bazar Shalom Online.
As imagens são salvas automaticamente pelo painel admin (admin.php).
